
	<script src="../librerias/jquery-3.4.1.min.js"></script>
	<script src="../librerias/bootstrap4/popper.min.js"></script>
	<script src="../librerias/bootstrap4/bootstrap.min.js"></script>
	<script src="../librerias/sweetalert.min.js"></script>
	<script src="../librerias/datatable/jquery.dataTables.min.js"></script>
	<script src="../librerias/datatable/dataTables.bootstrap4.min.js"></script>
	<script src="js/tesseract-ocr.js"></script>


	</body>
</html>